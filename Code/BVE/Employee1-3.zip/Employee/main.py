# Exercise 1
import Classes.EmployeeClass_1
from Classes.EmployeeClass_1 import Employee

name = input("Enter a name: ")
salary = int(input("Enter the salary: "))

employee1 = Employee(name, salary)
employee1.increase_salary(10)
print(employee1)

# Exercise 2
import Classes.EmployeeClass_2
from Classes.EmployeeClass_2 import Employee

employee2 = Employee(name)
print(employee2)
employee22 = Employee(name, salary)
print(employee22)

# Exercise 3
import Classes.EmployeeClass_3
from Classes.EmployeeClass_3 import Employee
from datetime import date

employee3 = Employee(salary = 234500, name = "Tom")
print(employee3)
employee3.set_birthday(employee3.create_date(1980,12,12))
print(employee3)
employee3.set_birthday(employee3.create_date(1980,'January',12))
print(employee3)

