
from multipledispatch import dispatch
from datetime import date
import calendar

class Employee:
	## Default age 25
	def __init__(self, name, birthday = date.today().replace(year=date.today().year - 25), salary=150000):
		## private data members
		self.__name = name
		self.__salary = salary
		self.__birthday = birthday

	def __str__(self):
		return "Name: " + self.get_name() + ", Salary: " + str(self.get_salary()) + ", Birthday: " + str(self.get_birthday())

	## getter and setter methods
	def get_name(self):
		return self.__name

	def set_name(self, name):
		self.__name = name

	def get_salary(self):
		return self.__salary

	def set_salary(self, salary):
		self.__salary = salary

	def get_birthday(self):
		return self.__birthday

	def set_birthday(self, birthday):
		self.__birthday = birthday

	##
	def increase_salary(self, percentage):
		self.__salary += self.__salary * percentage / 100

	## method overloading
	@dispatch(int, int, int)
	def create_date(year, month, day):
		return date(year, month, day)

	@dispatch(int, str, int)
	def create_date(year, month_name, day):
		month = list(calendar.month_name).index(month_name)
		return date(year, month, day)